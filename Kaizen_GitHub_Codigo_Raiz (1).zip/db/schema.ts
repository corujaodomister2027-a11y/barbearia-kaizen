import {sqliteTable,text,integer,uniqueIndex,index} from "drizzle-orm/sqlite-core";
export const bookings=sqliteTable("bookings",{id:text("id").primaryKey(),name:text("name").notNull(),phone:text("phone").notNull(),service:text("service").notNull(),date:text("date").notNull(),start:integer("start").notNull(),duration:integer("duration").notNull(),price:integer("price").notNull(),status:text("status").notNull().default("confirmed"),created:integer("created").notNull(),paymentExpires:integer("payment_expires"),paymentReported:integer("payment_reported"),paidAt:integer("paid_at"),manageHash:text("manage_hash"),serviceName:text("service_name"),priceCents:integer("price_cents")},t=>[index("idx_bookings_date").on(t.date),index("idx_bookings_status").on(t.status)]);
export const slots=sqliteTable("slots",{id:integer("id").primaryKey({autoIncrement:true}),date:text("date").notNull(),minute:integer("minute").notNull(),bookingId:text("booking_id").notNull()},t=>[uniqueIndex("idx_slots_date_minute").on(t.date,t.minute),index("idx_slots_booking").on(t.bookingId)]);

export const serviceSettings=sqliteTable("service_settings",{id:text("id").primaryKey(),name:text("name").notNull(),priceCents:integer("price_cents").notNull(),duration:integer("duration")});

export const barberCredentials=sqliteTable("barber_credentials",{id:text("id").primaryKey(),salt:text("salt").notNull(),hash:text("hash").notNull(),revision:integer("revision").notNull()});
export const siteSettings=sqliteTable("site_settings",{id:text("id").primaryKey(),isPublic:integer("is_public").notNull().default(1)});

export const weeklyHours=sqliteTable("weekly_hours",{weekday:integer("weekday").primaryKey(),enabled:integer("enabled").notNull(),opens:integer("opens").notNull(),closes:integer("closes").notNull()});
