CREATE TABLE `service_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`price_cents` integer NOT NULL
);
--> statement-breakpoint
ALTER TABLE `bookings` ADD `service_name` text;--> statement-breakpoint
ALTER TABLE `bookings` ADD `price_cents` integer;