CREATE TABLE `weekly_hours` (
	`weekday` integer PRIMARY KEY NOT NULL,
	`enabled` integer NOT NULL,
	`opens` integer NOT NULL,
	`closes` integer NOT NULL
);
