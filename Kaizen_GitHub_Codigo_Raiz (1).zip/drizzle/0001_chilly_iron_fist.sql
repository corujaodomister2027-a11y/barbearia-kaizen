ALTER TABLE `bookings` ADD `payment_expires` integer;--> statement-breakpoint
ALTER TABLE `bookings` ADD `payment_reported` integer;--> statement-breakpoint
ALTER TABLE `bookings` ADD `paid_at` integer;--> statement-breakpoint
ALTER TABLE `bookings` ADD `manage_hash` text;--> statement-breakpoint
CREATE INDEX `idx_bookings_status` ON `bookings` (`status`);