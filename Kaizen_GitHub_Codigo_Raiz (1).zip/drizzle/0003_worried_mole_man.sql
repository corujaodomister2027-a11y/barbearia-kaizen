CREATE TABLE `barber_credentials` (
	`id` text PRIMARY KEY NOT NULL,
	`salt` text NOT NULL,
	`hash` text NOT NULL,
	`revision` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `site_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`is_public` integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
ALTER TABLE `service_settings` ADD `duration` integer;