CREATE TABLE `bookings` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`service` text NOT NULL,
	`date` text NOT NULL,
	`start` integer NOT NULL,
	`duration` integer NOT NULL,
	`price` integer NOT NULL,
	`status` text DEFAULT 'confirmed' NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_bookings_date` ON `bookings` (`date`);--> statement-breakpoint
CREATE TABLE `slots` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`date` text NOT NULL,
	`minute` integer NOT NULL,
	`booking_id` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_slots_date_minute` ON `slots` (`date`,`minute`);--> statement-breakpoint
CREATE INDEX `idx_slots_booking` ON `slots` (`booking_id`);